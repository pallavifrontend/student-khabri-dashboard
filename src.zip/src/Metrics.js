import React from "react";
import leads from "./data";

const Metrics = () => {
  const total = leads.length;
  const converted = leads.filter(l => l.status === "Converted").length;
  const pending = leads.filter(l => l.status === "Pending").length;

  return (
    <div>
      <h2>Metrics</h2>
      <p>Total Leads: {total}</p>
      <p>Converted Leads: {converted}</p>
      <p>Pending Leads: {pending}</p>
    </div>
  );
};

export default Metrics;
