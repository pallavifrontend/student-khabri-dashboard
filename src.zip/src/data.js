const leads = [];

for (let i = 1; i <= 300; i++) {
  leads.push({
    id: i,
    name: `Lead ${i}`,
    email: `lead${i}@example.com`,
    status: i % 3 === 0 ? "Converted" : "Pending",
    stage: ["New", "Contacted", "Qualified"][i % 3]
  });
}

export default leads;
