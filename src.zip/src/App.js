function App() {
  const leads = [
    { id: 1, name: "Pallavi", email: "pallavi@gmail.com", status: "New" },
    { id: 2, name: "Juhi", email: "juhi@gmail.com", status: "Converted" },
    { id: 3, name: "Harshitha", email: "harshitha@gmail.com", status: "In Progress" }
  ];

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Student Khabri Lead Dashboard</h1>

      <h3>Analytics</h3>
      <p>Total Leads: {leads.length}</p>
      <p>Converted Leads: {leads.filter(l => l.status === "Converted").length}</p>
      <p>New Leads: {leads.filter(l => l.status === "New").length}</p>

      <h3>Leads List</h3>
      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => (
            <tr key={lead.id}>
              <td>{lead.name}</td>
              <td>{lead.email}</td>
              <td>{lead.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
